package idempotency

//import "github.com/Elton-hst/internal/infrastructure/redis"

// type Idempotency[T any] struct {
// 	redis *redis.Redis[T]
// }
