package redis

type Redis struct{
	
}