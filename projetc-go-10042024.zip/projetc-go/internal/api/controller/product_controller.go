package controller

import (
	"net/http"

	"github.com/Elton-hst/internal/api/rest"
	"github.com/Elton-hst/internal/application/logger"
	"github.com/Elton-hst/internal/domain/services"
	"github.com/labstack/echo/v4"
)

type ProductController struct {
	service services.ProductService
}

func NewProductController(service services.ProductService) *ProductController {
	return &ProductController{
		service: service,
	}
}

// CreateProduct godoc
// @Summary      Create product
// @Description  Add a new product
// @Accept       json
// @Produce      json
// @Param        product body rest.CreateProductRequest true "Product data"
// @Success      201 {object} aggregate.Product "Product created successfully"
// @Failure      400 {object} map[string]string "Bad request"
// @Router       /api/v1/product [post]
func (p *ProductController) CreateProduct(c echo.Context) error {
    var createProduct rest.CreateProductRequest

    if err := c.Bind(&createProduct); err != nil {
        return c.JSON(http.StatusBadRequest, map[string]string{
            "error": "Corpo da requisição está errado",
        })
    }

    product := createProduct.ToAggregate()
    logger.Info.Printf("Start create new product: %T", product)

    result, err := p.service.Create(product)
    if err != nil {
        return c.JSON(http.StatusBadRequest, map[string]string{
            "error": err.Error(),
        })
    }

    logger.Info.Print("Success on create new product")
    return c.JSON(http.StatusCreated, result)
}
