package main

import (
	"encoding/json"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"runtime"

	_ "github.com/Elton-hst/docs"
	"github.com/Elton-hst/internal/application/logger"
	"github.com/joho/godotenv"
)

func init() {
	_, b, _, _ := runtime.Caller(0)
	basepath := filepath.Dir(b)

	if err := godotenv.Load(basepath + "/.env"); err != nil {
		logger.Error.Println("Failed to fetch environment variables")
	}
}

type Credentials struct {
	ClientID     string `json:"client_id"`
	ProjectID    string `json:"project_id"`
	AuthURI      string `json:"auth_uri"`
	TokenURI     string `json:"token_uri"`
	AuthProvider string `json:"auth_provider_x509_cert_url"`
	ClientSecret string `json:"client_secret"`
}

// @title Swagger Example API
// @version 1.0
// @description This is a sample server for using Swagger with Echo.
// @host localhost:8080
// @BasePath /api/v1
func main() {
	// config.DataBaseInit()
	// defer config.GetDB().DB()

	// serve := server.NewServer()
	// seila := serve.Start()

	// if err := seila.Start(os.Getenv("SERVER")); err != nil {
	// 	logger.Error.Println("Failed to initialize the server")
	// }

	seila, err := ReadCredentials()
	if err != nil {
		log.Fatal(err)
	}
	fmt.Println(seila.ClientID)

}

func configErr(err error) {
	if err != nil {
		log.Fatal(err)
	}
}

func ReadCredentials() (Credentials, error) {
	var credentials Credentials

	jsonFile, err := os.ReadFile("./client_secret_781115238279-2lmr1gedii0agti22nap0skcldl7dpbg.apps.googleusercontent.com.json")
	configErr(err)

	err = json.Unmarshal(jsonFile, &credentials)
	configErr(err)

	redirection := fmt.Sprintf(
		"https://accounts.google.com/o/oauth2/v2/auth?" +
		"scope=https://www.googleapis.com/auth/drive.metadata.readonly&" +
		"access_type=offline&" +
		"include_granted_scopes=true&" +
		"response_type=code&" +
		"state=state_parameter_passthrough_value&" +
		"redirect_uri=https:localhost:8080/api/v1/auth&" +
		"client_id="+ credentials.ClientID,
	)

	fmt.Println(redirection)

	return credentials, nil
}
