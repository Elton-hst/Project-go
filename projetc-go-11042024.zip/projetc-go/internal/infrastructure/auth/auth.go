package auth

type Oauth2Client struct {
	ClientId     string
	ClientSecret string
	RedirectUri  string
}


