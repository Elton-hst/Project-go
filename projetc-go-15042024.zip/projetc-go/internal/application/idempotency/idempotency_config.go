package idempotency

import (
	"context"
	"encoding/json"
	"fmt"
	"sync"

	rd "github.com/redis/go-redis/v9"
	"github.com/Elton-hst/internal/infrastructure/redis"
)

type IdempotentHandler[T any] struct {
	redis *redis.Redis
	mutex sync.Mutex
}

func (i *IdempotentHandler[T]) Startt(ctx context.Context, idempotencyKey string) (T, error) {
	var t T

	tr := i.redis.Client.HSetNX(ctx, "idempotencyKey:"+idempotencyKey, "status", "start")
	if tr.Err() != nil {
		return t, tr.Err()
	}

	if tr.Val() {
		return t, nil
	}

	b := i.redis.Client.HGet(ctx, "idempotencyKey:"+idempotencyKey, "status")
	if b == nil {
		return t, nil
	}

	return t, nil
}

func (i *IdempotentHandler[T]) Store(ctx context.Context, idempotencyKey string, value T) error {
	b, err := json.Marshal(value)
	if err != nil {
		return err
	}

	return i.redis.Client.HSet(ctx, "idempotencyKey:"+idempotencyKey, "value", b).Err()
}

func (h *IdempotentHandler[T]) Start(ctx context.Context, key string, calculate func() interface{}) (interface{}, error) {
	h.mutex.Lock()
	defer h.mutex.Unlock()

	val, err := h.redis.Client.Get(ctx, key).Result()
	if err == nil {
		return val, nil
	} else if err != rd.Nil {
		return nil, fmt.Errorf("error checking key in Redis: %v", err)
	}

	result := calculate()

	if err := h.redis.Client.Set(ctx, key, result, 0).Err(); err != nil {
		return nil, fmt.Errorf("error setting key in Redis: %v", err)
	}

	return result, nil
}
