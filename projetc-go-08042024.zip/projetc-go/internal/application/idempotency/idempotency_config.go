package idempotency

// type Idempotency[T any] struct {
// 	redis *redis.Redis[T]
// }
