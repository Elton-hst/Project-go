package behavior

type Result struct {
	IsError bool
	Success   interface{}
	Problem   error
}

func Success(value interface{}) *Result {
	return &Result{
		Success:   value,
		IsError: true,
	}
}

func IsFail(err error) *Result {
	return &Result{
		Problem:   err,
		IsError: false,
	}
}

func (r *Result) GetError() bool {
	return r.IsError
}

func (r *Result) GetSuccess() interface{} {
	return r.Success
}

func (r *Result) GetFail() error {
	return r.Problem 
}
