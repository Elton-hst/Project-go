package router

import (
	"github.com/Elton-hst/internal/api/controller"
	"github.com/labstack/echo/v4"
)

type Router struct {
	Echo              *echo.Echo
	ProductController controller.ProductController
}

func NewRouter(echo *echo.Echo, productController controller.ProductController) *Router {
	return &Router{
		Echo:              echo,
		ProductController: productController,
	}
}

func (r *Router) Router() *echo.Echo {
	r.Echo.GET("/product", r.ProductController.CreateProduct)
	return r.Echo
}
