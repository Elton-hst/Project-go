package server

import (
	"os"

	"github.com/Elton-hst/internal/api/dependency"
	"github.com/Elton-hst/internal/application/logger"
	"github.com/Elton-hst/internal/infrastructure/database/config"
	"github.com/labstack/echo/v4"
	echoSwagger "github.com/swaggo/echo-swagger"
)

type Server struct {
	server *echo.Echo
	Port   int
}

func NewServer() *Server {
	return &Server{
		server: echo.New(),
	}
}

func (s *Server) Start() {
	logger.Info.Println("Initialize server")

	dependency.Dependency(config.GetDB(), s.server)

	s.server.GET("/swagger/*", echoSwagger.WrapHandler)
	s.server.GET("/ping", healthCheck)

	if err := s.server.Start(os.Getenv("SERVER")); err != nil {
		logger.Error.Println("Failed to initialize the server")
	}
}

func (s *Server) GetServer() *echo.Echo {
	return s.server
}

func healthCheck(c echo.Context) error {
	return c.JSON(200, "pong")
}
