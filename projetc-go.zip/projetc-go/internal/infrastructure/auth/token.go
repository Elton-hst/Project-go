package main

import (
	"encoding/json"
	"os"

	"golang.org/x/oauth2/jwt"
)

type Credentials struct {
	Type         string `json:"type"`
	ProjectId    string `json:"project_id"`
	PrivateKeyId string `json:"private_key_id"`
	PrivateKey   string `json:"private_key"`
	ClientEmail  string `json:"client_email"`
	ClientID     string `json:"client_id"`
	AuthURI      string `json:"auth_uri"`
	TokenURL     string `json:"token_uri"`
	AuthProvider string `json:"auth_provider_x509_cert_url"`
	ClientURL    string `json:"client_x509_cert_url"`
	Universe     string `json:"universe_domain"`
}

func NewToken(credentials *Credentials) *jwt.Config {

	tok := jwt.Config{
		Email:      credentials.ClientEmail,
		PrivateKey: []byte(credentials.PrivateKey),
		Subject: "eltonhst34@gmail.com",
	}

	return &tok
}

func SetupCredentials() (*Credentials, error) {
	var credentials Credentials

	jsonFile, err := os.ReadFile("../../../credentials.json")
	if err != nil {
		return nil, err
	}

	err = json.Unmarshal(jsonFile, &credentials)
	if err != nil {
		return nil, err
	}

	return &credentials, nil
}
